function displayFiles() {
    const input = document.getElementById('fileInput');
    const files = input.files;
    const fileList = document.getElementById('fileList');

    fileList.innerHTML = ''; // Clear previous entries

    if (files.length === 0) {
        alert('No file selected');
    } else {
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const listItem = document.createElement('li');
            listItem.textContent = file.name;
            fileList.appendChild(listItem);
        }
    }
}
